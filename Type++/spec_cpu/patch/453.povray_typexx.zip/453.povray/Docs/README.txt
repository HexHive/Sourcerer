The SPEC version of POV-Ray is to be used only for the
measurement and characterization of computers.
