#include "frame.h"

BEGIN_POV_NAMESPACE
void spec_srand(int seed);
double spec_rand(void);
END_POV_NAMESPACE
